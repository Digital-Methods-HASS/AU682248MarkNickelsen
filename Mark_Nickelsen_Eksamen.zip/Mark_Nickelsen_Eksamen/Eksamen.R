install.packages("tidyverse")
install.packages("here")
install.packages("dplyr")
install.packages("ggplot2")


library(tidyverse)
library(here)
library(dplyr)
library(ggplot2)


read_csv("data/Ballondor.csv")

Bdor <- read_delim("data/ballondor.csv")

# Visualisering

# Defining Playernationality_count and remove NA values
Playernationality_count<-as.data.frame(table(Bdor$Playernationality))
Playernationality_count<-na.omit(Playernationality_count)

# ggplot Ballon d'Or pr Nation
ggplot(Playernationality_count, aes(x=Var1, y=Freq, fill=Var1))+
  geom_bar(stat="identity")+
  geom_text(aes(label=Freq),vjust=0)+
  labs(title="Ballon D'or pr Nation",
       y="Number of Ballon D'or", x="Countries",fill="Countries")+
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=8, angle=90),
        axis.text.y = element_text(face="bold", color="#993333", 
                                   size=14, angle=45))+
scale_y_continuous(limit = c(0, 8))

# Ballon d'Or pr Club
Club_count<-as.data.frame(table(Bdor$Club))
Club_count<-na.omit(Club_count)

ggplot(Club_count, aes(x=Var1, y=Freq, fill=Var1))+
  geom_bar(stat="identity")+
  geom_text(aes(label=Freq),vjust=0)+
  labs(title="Ballon D'or pr Club",
       y="Number of Ballon D'or", x="Club")+
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=8, angle=90),
        axis.text.y = element_text(face="bold", color="#993333", 
                                   size=14, angle=45))+
  scale_y_continuous(limit = c(0, 15))

# Ballon D'or pr League
League_count<-as.data.frame(table(Bdor$Clubnationality))
League_count<-na.omit(League_count)

ggplot(League_count, aes(x=Var1, y=Freq, fill=Var1))+
  geom_bar(stat="identity")+
  geom_text(aes(label=Freq),vjust=0)+
  labs(title="Ballon D'or pr League",
       y="Number of Ballon D'or", x="Country of League",fill="Country of League")+
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=8, angle=90),
        axis.text.y = element_text(face="bold", color="#993333", 
                                   size=14, angle=45))+
  scale_y_continuous(limit = c(0, 30))
  

# Ballon d'Or pr Position
Position_count<-as.data.frame(table(Bdor$Position))
Position_count<-na.omit(Position_count)

ggplot(Position_count, aes(x=Var1, y=Freq, fill=Var1))+
  geom_bar(stat="identity")+
  geom_text(aes(label=Freq),vjust=0)+
  labs(title="Ballon D'or pr Position",
       y="Number of Ballon D'or", x="Position",fill="Position")+
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=8, angle=90),
        axis.text.y = element_text(face="bold", color="#993333", 
                                   size=14, angle=45))+
  scale_y_continuous(limit = c(0, 50))

# Ballon d'Or pr Player
Player_count<-as.data.frame(table(Bdor$Name))
Player_count<-na.omit(Player_count)

ggplot(Player_count, aes(x=Var1, y=Freq, fill=Var1))+
  geom_bar(stat="identity")+
  geom_text(aes(label=Freq),vjust=0)+
  labs(title="Ballon D'or pr Player",
       y="Number of Ballon D'or", x="Name of Player",fill="Name of Players")+
  theme(axis.text.x = element_text(face="bold", color="#993333", 
                                   size=8, angle=90),
        axis.text.y = element_text(face="bold", color="#993333", 
                                   size=14, angle=45))+
  scale_y_continuous(limit = c(0, 10))